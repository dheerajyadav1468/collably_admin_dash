export type purchaseProduct = {
    image: string;
    name: string;
    creator:string;
    quantity:number;
    amount: number;
    purchaseDate: string;
  };
export type BRAND = {
  logo: string;
  name: string;
  products: number;
  revenues: string;
  sales: number;
  conversion: number;
};



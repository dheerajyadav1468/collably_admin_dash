'use client';

import { useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import { useDispatch, useSelector } from 'react-redux';
import { AppDispatch, RootState } from '../../app/store/store';
import { fetchBrand } from '../../app/store/brandSlice';
import TableTwo from "../Tables/TableTwo";

const ProfileBrand = () => {
  const dispatch = useDispatch<AppDispatch>();
  const searchParams = useSearchParams();
  const brandId = searchParams.get('id');
  const { currentBrand, status, error } = useSelector((state: RootState) => state.brands);

  useEffect(() => {
    if (brandId) {
      dispatch(fetchBrand(brandId));
    }
  }, [dispatch, brandId]);

  if (status === 'loading') return <div>Loading...</div>;
  if (status === 'failed') return <div>Error: {error}</div>;
  if (!currentBrand) return <div>No brand found</div>;

  return (
    <div className="p-6 bg-white dark:bg-gray-dark rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-4 text-dark dark:text-white">
        {currentBrand.brandName} - Brand Details
      </h2>
      <div className='brandcover'>
        <img src="/images/brand/brand-01.svg" alt={currentBrand.brandName} className="mb-4 w-24 h-24" />
        <div>
          <p className="text-lg text-dark dark:text-gray-300">
            <strong>Category:</strong> {currentBrand.brandCategory}
          </p>
          <p className="text-lg text-dark dark:text-gray-300">
            <strong>Email:</strong> {currentBrand.contactEmail}
          </p>
          <p className="text-lg text-dark dark:text-gray-300">
            <strong>Website:</strong> {currentBrand.brandWebsite}
          </p>
          <p className="text-lg text-dark dark:text-gray-300">
            <strong>Phone:</strong> {currentBrand.brandPhoneNumber}
          </p>
          <p className="text-lg text-dark dark:text-gray-300">
            <strong>GST Number:</strong> {currentBrand.gstNumber}
          </p>
        </div>
      </div>
      <div className="mt-6">
        <h3 className="text-xl font-bold mb-2 text-dark dark:text-white">Description</h3>
        <p className="text-dark dark:text-gray-300">{currentBrand.brandDescription}</p>
      </div>
      <div className="mt-6">
        <h3 className="text-xl font-bold mb-2 text-dark dark:text-white">Social Media Links</h3>
        <ul className="list-disc pl-5">
          {Object.entries(currentBrand.socialMediaLinks).map(([platform, link]) => (
            <li key={platform} className="text-dark dark:text-gray-300">
              <strong className="capitalize">{platform}:</strong> {link}
            </li>
          ))}
        </ul>
      </div>
      <TableTwo />
    </div>
  );
};

export default ProfileBrand;

